import React from 'react';

export default class Inicio extends React.Component {
    constructor(props) {
        super(props);
        this.state = {};
    }
    render() { 
        return ( 

        <h1 style={{marginTop:200}}>Pagina de Inicio</h1>

        );
    }
}
 

